#pragma once

#include <regex>
#include <string>
#include <windows.h>
#include <iostream>
#include "SAMPFUNCS_API.h"
#include "game_api.h"
#include "ur_mem/urmem.hpp"


extern SAMPFUNCS *SF;
